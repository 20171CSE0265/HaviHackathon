<?php
$connection = mysqli_connect("sql206.epizy.com","epiz_26965071","k4gOUAobp5hT","epiz_26965071_havi");
if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $name=$_POST['name'];
    $result=mysqli_query($connection,"INSERT into product values('$id','$name')");
    if($result)
    {
        header("location:welcome.php");
    }
    else{
        echo "failed";
    }
}